 
 
using UnityEngine;

namespace SLZ.Marrow.Warehouse
{
    public class SpawnableCrate : GameObjectCrate
    {
    }
}