 
 
using UnityEngine;

namespace SLZ.Marrow.Warehouse
{
    public class AvatarCrate : SpawnableCrate
    {
    }
}