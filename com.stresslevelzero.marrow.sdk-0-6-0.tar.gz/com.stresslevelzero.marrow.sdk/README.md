# Marrow SDK
SDK Tools used to make Mods for the Marrow Interaction Engine, packaged content in Crates stacked on Pallets.  
# [Documentation](https://github.com/StressLevelZero/MarrowSDK/wiki)