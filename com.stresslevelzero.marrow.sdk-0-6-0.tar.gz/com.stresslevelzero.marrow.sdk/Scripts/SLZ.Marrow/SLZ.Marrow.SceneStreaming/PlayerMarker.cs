 
 
 
using UnityEngine;

#if UNITY_EDITOR
  

#endif
namespace SLZ.Marrow.SceneStreaming
{
    [AddComponentMenu("MarrowSDK/Player Marker")]
    public class PlayerMarker : MonoBehaviour
    {
#if UNITY_EDITOR
#endif
    }
}